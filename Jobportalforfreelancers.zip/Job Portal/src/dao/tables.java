/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;
import javax.swing.JOptionPane;
/**
 *
 * @author VAIDEHI
 */
public class tables {
    public static void main(String[]args){
        try{
          // String userTable = "create table user(id int AUTO_INCREMENT primary key, name varchar(200),email varchar(200),contact varchar(10), field varchar(200),securityquestion varchar(200), answer varchar(200),password varchar(200),status varchar(200), UNIQUE(email))";
           // String adminDetails = "insert into user(name,email,contact,field,securityquestion, answer,password,status) values('Admin','admin@gmail.com','1234567890','admin','which year?','2022','admin@12345','true')";
            String Jobvacancies ="create table Jobvacancies(id int AUTO_INCREMENT primary key, jobname varchar(200), jobdesc varchar(3000), email varchar(200))";
            //DbOperations.setDataorDelete(userTable, "User table created successfully");
           // DbOperations.setDataorDelete(adminDetails, "Admin details added successfully");
            DbOperations.setDataorDelete(Jobvacancies, "Job vacancies table created successfully");
        }
        catch(Exception e){
            JOptionPane.showMessageDialog(null,e);
        }
    }
}
