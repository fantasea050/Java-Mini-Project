/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;

import model.User;
import javax.swing.JOptionPane;
import java.util.ArrayList;
import java.sql.*;

/**
 *
 * @author VAIDEHI
 */
public class Userdao {

    public static void save(User user) {
        String query = "insert into user(name,email,contact,field,securityquestion,answer,password,status) values('" + user.getName() + "','" + user.getEmail() + "','" + user.getMobileNumber() + "','" + user.getField() + "','" + user.getSecurityQuestion() + "','" + user.getAnswer() + "','" + user.getPassword() + "','false')";
        DbOperations.setDataorDelete(query, "Registered Successfully! Wait for confirmation within 24 hours of Admin Approval");
    }

    public static User login(String email, String password) {
        User user = null;
        try {
            ResultSet rs = DbOperations.getData("Select * from user where email='" + email + "' and password='" + password + "'");
            while (rs.next()) {
                user = new User();
                user.setStatus(rs.getString("status"));
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
        }
        return user;
    }

    public static User getSecurityQuestion(String email) {
        User user = null;
        try {
            ResultSet rs = DbOperations.getData("select*from user where email='" + email + "'");
            while (rs.next()) {
                user = new User();
                user.setSecurityQuestion(rs.getString("securityQuestion"));
                user.setAnswer(rs.getString("answer"));

            }

        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
        }
        return user;
    }

    public static void update(String email, String Password) {
        String query = "update user set password='" + Password + "' where email='" + email + "'";
        DbOperations.setDataorDelete(query, "Password changes successfully");
    }

    public static ArrayList<User> getAllRecords(String email) {
        ArrayList<User> arrayList = new ArrayList<>();
        try {

            ResultSet rs = DbOperations.getData("select*from user where email like'%" + email + "%'");
            while (rs.next()) {
                User user = new User();
                user.setId(rs.getInt("id"));
                user.setName(rs.getString("name"));
                user.setEmail(rs.getString("email"));
                user.setMobileNumber(rs.getString("contact"));
                user.setField(rs.getString("field"));
                user.setSecurityQuestion(rs.getString("securityquestion"));
                user.setStatus(rs.getString("status"));
                arrayList.add(user);

            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
        }
        return arrayList;
    }

    public static void changeStatus(String email, String status) {
        String query = "update user set status='" + status + "' where email='" + email + "'";
        DbOperations.setDataorDelete(query, "Status changed successfully");

    }

    public static ArrayList<User> getAllRecordsDisplay() {
        ArrayList<User> arrayList = new ArrayList<>();
        try {

            ResultSet rs = DbOperations.getData("select*from user");
            while (rs.next()) {
                User user = new User();
                user.setId(rs.getInt("id"));
                user.setName(rs.getString("name"));
                user.setEmail(rs.getString("email"));
                user.setMobileNumber(rs.getString("contact"));
                user.setField(rs.getString("field"));

                arrayList.add(user);

            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
        }
        return arrayList;
    }
}
