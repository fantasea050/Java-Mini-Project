/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;
import java.util.ArrayList;
import java.sql.*;
import javax.swing.JOptionPane;
import model.JobVac;


/**
 *
 * @author VAIDEHI
 */
public class Jobvacanciesdao {
    public static void save(JobVac jobvacancies){
        String query = "insert into jobvacancies(jobname,jobdesc,email) values('"+jobvacancies.getJname()+"','"+jobvacancies.getJdesc()+"','"+jobvacancies.getEmail()+"')"; 

       
        DbOperations.setDataorDelete(query,"Job vancancy added successfully");
        
        
    }
    
    
    public static ArrayList<JobVac> getAllRecords(String email){
        ArrayList<JobVac> arrayList = new ArrayList<>();
        try{
           ResultSet rs =DbOperations.getData("select * from jobvacancies");
           while(rs.next()){
               JobVac jobvacancies = new JobVac();
               jobvacancies.setId(rs.getInt("id"));
               jobvacancies.setJname(rs.getString("jobname"));
               jobvacancies.setJdesc(rs.getString("jobdesc"));
               jobvacancies.setEmail(rs.getString("email"));
               arrayList.add(jobvacancies);
               
           }
        }
    
        catch(Exception e){
            JOptionPane.showMessageDialog(null,e);
        }
        return arrayList;
    }
    
    
    public static void delete(String id){
        String query ="delete from jobvacancies where id='"+id+"'";
        DbOperations.setDataorDelete(query,"Vacancy deleted successfully");
                
                
    }
    
    public static ArrayList<JobVac> getAllRecordsDisplay(){
        ArrayList<JobVac> arrayList = new ArrayList<>();
        try{
           ResultSet rs =DbOperations.getData("select * from jobvacancies");
           while(rs.next()){
               JobVac jobvacancies = new JobVac();
               jobvacancies.setId(rs.getInt("id"));
               jobvacancies.setJname(rs.getString("jobname"));
               jobvacancies.setJdesc(rs.getString("jobdesc"));
               jobvacancies.setEmail(rs.getString("email"));
               arrayList.add(jobvacancies);
               
           }
        }
    
        catch(Exception e){
            JOptionPane.showMessageDialog(null,e);
        }
        return arrayList;
    }
}
