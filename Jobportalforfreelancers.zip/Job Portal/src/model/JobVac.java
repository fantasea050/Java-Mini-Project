/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

/**
 *
 * @author VAIDEHI
 */
public class JobVac {
    
    private int id;
    private String jobname;
    private String jobdesc;
    private String email;
    

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }
    
    

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getJname() {
        return jobname;
    }

    public void setJname(String jname) {
        this.jobname = jname;
    }

    public String getJdesc() {
        return jobdesc;
    }

    public void setJdesc(String jdesc) {
        this.jobdesc = jdesc;
    }
    
}
